# CSC73010-ionic-file-storage
Example ionic app using File storage

This is the source code for a simple app to demonstrate ionic file storage.  It is only the src/ directory!
You will need to provide the ionic project directories.

This source code was compiled and tested with Android 7.1.1.  Note that the srcv3/ directory is sources for ionic version 3 and src/ directory is for ionic 4.
